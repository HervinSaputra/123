import { AppLayout } from "@/components/layout";
import { useCampaign, useCampaignContacts } from "@/hooks/use-campaigns";
import { useRoute } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw, CheckCircle2, Clock, XCircle, MailOpen, Reply, AlertCircle, Smartphone } from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

export default function CampaignResults() {
  const [, params] = useRoute("/campaigns/:id");
  const campaignId = parseInt(params?.id || "0");
  
  const { data: campaign, isLoading: isLoadingCampaign } = useCampaign(campaignId);
  const { data: contacts, isLoading: isLoadingContacts, refetch, isRefetching } = useCampaignContacts(campaignId);

  const stats = {
    total: contacts?.length || 0,
    pending: contacts?.filter(c => c.status === 'pending').length || 0,
    sent: contacts?.filter(c => c.status === 'sent' || c.status === 'delivered').length || 0,
    read: contacts?.filter(c => c.status === 'read').length || 0,
    replied: contacts?.filter(c => c.status === 'replied').length || 0,
    failed: contacts?.filter(c => c.status === 'failed').length || 0,
  };

  const progress = stats.total > 0 ? ((stats.sent + stats.read + stats.replied + stats.failed) / stats.total) * 100 : 0;

  if (isLoadingCampaign) return (
    <AppLayout>
      <div className="p-8 space-y-6">
        <Skeleton className="h-12 w-64 rounded-xl" />
        <Skeleton className="h-48 w-full rounded-2xl" />
      </div>
    </AppLayout>
  );

  if (!campaign) return (
    <AppLayout>
      <div className="p-8 text-center text-muted-foreground flex flex-col items-center justify-center min-h-[50vh]">
        <AlertCircle className="w-16 h-16 mb-4 opacity-20" />
        <h2 className="text-2xl font-display font-bold text-foreground">Campaign not found</h2>
        <p className="mt-2">The campaign you are looking for does not exist.</p>
      </div>
    </AppLayout>
  );

  return (
    <AppLayout>
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-4xl font-display font-bold tracking-tight">{campaign.name}</h1>
              <span className={`text-xs font-semibold px-3 py-1 rounded-full border uppercase tracking-wider ${
                campaign.status === 'running' ? 'bg-primary/10 text-primary border-primary/20' : 
                campaign.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' :
                'bg-muted text-muted-foreground border-border'
              }`}>
                {campaign.status}
              </span>
            </div>
            <div className="text-muted-foreground mt-2 space-y-1">
              <p className="flex items-center gap-2">
                <Smartphone className="w-4 h-4" /> Server: {(campaign as any).serverName || (campaign as any).serverPhone || 'Unknown'}
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4" /> Created on {campaign.createdAt ? format(new Date(campaign.createdAt), 'PPpp') : 'Unknown'}
              </p>
            </div>
          </div>
          <Button 
            onClick={() => refetch()} 
            disabled={isRefetching}
            variant="outline" 
            className="rounded-xl border-border/50 bg-secondary/50 backdrop-blur-sm"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRefetching ? 'animate-spin' : ''}`} /> 
            Refresh Stats
          </Button>
        </div>

        {/* Progress & Overview */}
        <Card className="glass-panel border-border/50 shadow-2xl">
          <CardContent className="p-8">
            <div className="mb-6">
              <div className="flex justify-between text-sm font-medium mb-2">
                <span>Campaign Progress</span>
                <span className="text-primary">{Math.round(progress)}% Complete</span>
              </div>
              <div className="w-full bg-secondary rounded-full h-3 overflow-hidden border border-border/50">
                <div 
                  className="bg-gradient-to-r from-primary to-accent h-full rounded-full transition-all duration-1000 ease-out" 
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 pt-6 border-t border-border/50">
              <StatItem label="Total Audience" value={stats.total} />
              <StatItem label="Pending" value={stats.pending} icon={Clock} color="text-amber-500" />
              <StatItem label="Sent" value={stats.sent} icon={CheckCircle2} color="text-primary" />
              <StatItem label="Read/Replied" value={stats.read + stats.replied} icon={MailOpen} color="text-emerald-500" />
              <StatItem label="Failed" value={stats.failed} icon={XCircle} color="text-destructive" />
            </div>
          </CardContent>
        </Card>

        {/* Contacts Table */}
        <Card className="glass-panel border-border/50">
          <CardHeader className="border-b border-border/50 bg-secondary/20">
            <CardTitle className="font-display flex items-center gap-2">
              Delivery Logs
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-secondary/40 text-muted-foreground font-medium uppercase text-xs tracking-wider">
                  <tr>
                    <th className="px-6 py-4 rounded-tl-xl">Phone Number</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Sent At</th>
                    <th className="px-6 py-4">Read/Reply At</th>
                    <th className="px-6 py-4 rounded-tr-xl">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border/50">
                  {isLoadingContacts ? (
                    <tr><td colSpan={5} className="p-8 text-center"><RefreshCw className="w-6 h-6 animate-spin mx-auto text-primary" /></td></tr>
                  ) : contacts?.length === 0 ? (
                    <tr><td colSpan={5} className="p-8 text-center text-muted-foreground">No contacts in this campaign.</td></tr>
                  ) : (
                    contacts?.map((contact) => (
                      <tr key={contact.id} className="hover:bg-secondary/20 transition-colors">
                        <td className="px-6 py-4 font-mono">{contact.phone}</td>
                        <td className="px-6 py-4">
                          <ContactStatusBadge status={contact.status} />
                        </td>
                        <td className="px-6 py-4 text-muted-foreground">
                          {contact.sentAt ? format(new Date(contact.sentAt), 'HH:mm:ss') : '-'}
                        </td>
                        <td className="px-6 py-4 text-muted-foreground">
                          {contact.readAt ? format(new Date(contact.readAt), 'HH:mm:ss') : '-'}
                        </td>
                        <td className="px-6 py-4 text-xs">
                          {contact.errorMessage ? <span className="text-destructive">{contact.errorMessage}</span> : '-'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}

function StatItem({ label, value, icon: Icon, color = "text-foreground" }: any) {
  return (
    <div className="text-center">
      <div className={`flex items-center justify-center gap-2 mb-1 ${color}`}>
        {Icon && <Icon className="w-4 h-4" />}
        <span className="text-2xl font-display font-bold">{value}</span>
      </div>
      <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">{label}</p>
    </div>
  );
}

function ContactStatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string, icon: any, text: string }> = {
    pending: { bg: 'bg-amber-500/10 text-amber-500', icon: Clock, text: 'Pending' },
    sent: { bg: 'bg-primary/10 text-primary', icon: CheckCircle2, text: 'Sent' },
    delivered: { bg: 'bg-primary/20 text-primary', icon: CheckCircle2, text: 'Delivered' },
    read: { bg: 'bg-emerald-500/10 text-emerald-500', icon: MailOpen, text: 'Read' },
    replied: { bg: 'bg-emerald-600/20 text-emerald-500', icon: Reply, text: 'Replied' },
    failed: { bg: 'bg-destructive/10 text-destructive', icon: XCircle, text: 'Failed' },
  };

  const config = configs[status] || configs.pending;
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border border-current/20 ${config.bg}`}>
      <Icon className="w-3 h-3" /> {config.text}
    </span>
  );
}
