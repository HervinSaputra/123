import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { whatsAppService } from "./baileys";
import multer from "multer";
import path from "path";
import fs from "fs";

// Map to track ongoing campaign runs
const runningCampaigns = new Map<number, boolean>();
const pausedCampaigns = new Map<number, boolean>();

// Multer config for file uploads
const upload = multer({
  dest: "uploads/",
  limits: { fileSize: 50 * 1024 * 1024 },
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  whatsAppService.restoreSessions(async (id, status, qrCode) => {
    try { await storage.updateServerStatus(id, status, qrCode); } catch {}
  });

  // ── SERVERS ────────────────────────────────────────────────────────────────
  app.get(api.servers.list.path, async (req, res) => {
    const servers = await storage.getServers();
    for (const s of servers) {
      const liveStatus = whatsAppService.getSessionStatus(s.id);
      if (liveStatus !== s.status && liveStatus !== "disconnected") {
        await storage.updateServerStatus(s.id, liveStatus);
      }
    }
    res.json(await storage.getServers());
  });

  app.get(api.servers.get.path, async (req, res) => {
    const server = await storage.getServer(Number(req.params.id));
    if (!server) return res.status(404).json({ message: "Server not found" });
    const liveStatus = whatsAppService.getSessionStatus(server.id);
    if (liveStatus && liveStatus !== "disconnected" && liveStatus !== server.status) {
      const updated = await storage.updateServerStatus(server.id, liveStatus);
      return res.json(updated);
    }
    res.json(server);
  });

  app.post(api.servers.create.path, async (req, res) => {
    try {
      const input = api.servers.create.input.parse(req.body);
      const server = await storage.createServer(input);
      res.status(201).json(server);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  app.delete(api.servers.delete.path, async (req, res) => {
    const id = Number(req.params.id);
    await whatsAppService.disconnectSession(id);
    await storage.deleteServer(id);
    res.status(204).send();
  });

  app.post(api.servers.connect.path, async (req, res) => {
    const server = await storage.getServer(Number(req.params.id));
    if (!server) return res.status(404).json({ message: "Server not found" });
    try {
      await storage.updateServerStatus(server.id, "connecting");
      whatsAppService.initializeSession(server.id, server.phone, server.name, async (status, qrCode) => {
        try { await storage.updateServerStatus(server.id, status, qrCode); } catch {}
      }).catch((err) => {
        console.error("[Routes] initializeSession error:", err.message);
        storage.updateServerStatus(server.id, "disconnected").catch(() => {});
      });
      res.json({ message: "Connection initiated." });
    } catch (err: any) {
      await storage.updateServerStatus(server.id, "disconnected");
      res.status(500).json({ message: err.message });
    }
  });

  // ── CAMPAIGNS ──────────────────────────────────────────────────────────────
  app.get(api.campaigns.list.path, async (req, res) => {
    const campaigns = await storage.getCampaigns();
    for (const c of campaigns) {
      if (c.status === "scheduled" && c.scheduleTime) {
        if (new Date(c.scheduleTime) <= new Date()) {
          await startCampaignBackground(c.id);
        }
      }
    }
    res.json(await storage.getCampaigns());
  });

  app.get(api.campaigns.get.path, async (req, res) => {
    const campaign = await storage.getCampaign(Number(req.params.id));
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    res.json(campaign);
  });

  app.post(api.campaigns.create.path, async (req, res) => {
    try {
      const input = api.campaigns.create.input.parse(req.body);
      const campaign = await storage.createCampaign(input);
      res.status(201).json(campaign);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  // Delete campaign
  app.delete("/api/campaigns/:id", async (req, res) => {
    const id = Number(req.params.id);
    runningCampaigns.set(id, false);
    pausedCampaigns.delete(id);
    await storage.deleteCampaign(id);
    res.status(204).send();
  });

  app.post(api.campaigns.start.path, async (req, res) => {
    const campaign = await storage.getCampaign(Number(req.params.id));
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    pausedCampaigns.delete(campaign.id);
    await storage.updateCampaignStatus(campaign.id, "running");
    startCampaignBackground(campaign.id);
    res.json({ message: "Campaign started." });
  });

  // Pause
  app.post("/api/campaigns/:id/pause", async (req, res) => {
    const id = Number(req.params.id);
    const campaign = await storage.getCampaign(id);
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    pausedCampaigns.set(id, true);
    await storage.updateCampaignStatus(id, "paused");
    res.json({ message: "Campaign paused." });
  });

  // Resume
  app.post("/api/campaigns/:id/resume", async (req, res) => {
    const id = Number(req.params.id);
    const campaign = await storage.getCampaign(id);
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    pausedCampaigns.delete(id);
    await storage.updateCampaignStatus(id, "running");
    startCampaignBackground(id);
    res.json({ message: "Campaign resumed." });
  });

  // Stop
  app.post("/api/campaigns/:id/stop", async (req, res) => {
    const id = Number(req.params.id);
    const campaign = await storage.getCampaign(id);
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    runningCampaigns.set(id, false);
    pausedCampaigns.delete(id);
    await storage.updateCampaignStatus(id, "failed");
    res.json({ message: "Campaign stopped." });
  });

  // Schedule
  app.post("/api/campaigns/:id/schedule", async (req, res) => {
    const campaign = await storage.getCampaign(Number(req.params.id));
    if (!campaign) return res.status(404).json({ message: "Campaign not found" });
    const { scheduleTime } = req.body;
    if (!scheduleTime) return res.status(400).json({ message: "scheduleTime diperlukan" });
    const scheduleDate = new Date(scheduleTime);
    if (isNaN(scheduleDate.getTime())) return res.status(400).json({ message: "Format tidak valid" });
    if (scheduleDate <= new Date()) return res.status(400).json({ message: "Waktu harus di masa depan" });
    const updated = await storage.scheduleCampaign(campaign.id, scheduleDate);
    const msUntilRun = scheduleDate.getTime() - Date.now();
    setTimeout(() => startCampaignBackground(campaign.id), msUntilRun);
    res.json(updated);
  });

  // Delivery rate
  app.get("/api/stats/delivery-rate", async (req, res) => {
    const rate = await storage.getDeliveryRate();
    res.json({ rate });
  });

  // ── CONTACTS ───────────────────────────────────────────────────────────────
  app.get(api.contacts.list.path, async (req, res) => {
    const contacts = await storage.getCampaignContacts(Number(req.params.campaignId));
    res.json(contacts);
  });

  app.post(api.contacts.createBulk.path, async (req, res) => {
    try {
      const { contacts } = api.contacts.createBulk.input.parse(req.body);
      const campaignId = Number(req.params.campaignId);
      const insertData = contacts.map((c) => ({ ...c, campaignId }));
      await storage.createCampaignContacts(insertData);
      res.status(201).json({ count: contacts.length });
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ message: err.errors[0].message });
      throw err;
    }
  });

  // ── FILE UPLOAD ────────────────────────────────────────────────────────────
  app.post("/api/upload/media", upload.single("file"), async (req: any, res: any) => {
    if (!req.file) return res.status(400).json({ message: "No file uploaded" });
    const url = `/uploads/${req.file.filename}`;
    res.json({ url, filename: req.file.originalname, mimetype: req.file.mimetype });
  });

  app.use("/uploads", (req: any, res: any, next: any) => {
    const filePath = path.join(process.cwd(), "uploads", req.path.replace(/^\//, ""));
    if (fs.existsSync(filePath)) res.sendFile(filePath);
    else next();
  });

  app.post(api.upload.create.path, async (req, res) => {
    res.json({ url: "/uploads/dummy.pdf", filename: "dummy.pdf" });
  });
  app.post(api.upload.parseFile.path, async (req, res) => {
    res.json({ data: [] });
  });

  // ── GROUPS ─────────────────────────────────────────────────────────────────
  app.get(api.campaigns.groups.path, async (req, res) => {
    const serverId = Number(req.params.id);
    try {
      const groups = await whatsAppService.getGroups(serverId);
      res.json(groups);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  return httpServer;
}

// ── Background campaign runner ────────────────────────────────────────────────
async function startCampaignBackground(campaignId: number): Promise<void> {
  if (runningCampaigns.get(campaignId)) return;
  runningCampaigns.set(campaignId, true);
  pausedCampaigns.delete(campaignId);

  try {
    const campaign = await storage.getCampaign(campaignId);
    if (!campaign || !campaign.serverId) return;

    const contacts = await storage.getCampaignContacts(campaignId);
    const pendingContacts = contacts.filter((c) => c.status === "pending");
    if (pendingContacts.length === 0) {
      await storage.updateCampaignStatus(campaignId, "completed");
      runningCampaigns.delete(campaignId);
      return;
    }

    await storage.updateCampaignStatus(campaignId, "running");

    for (let i = 0; i < pendingContacts.length; i++) {
      if (!runningCampaigns.get(campaignId)) break;

      // Wait while paused
      while (pausedCampaigns.get(campaignId)) {
        await new Promise((r) => setTimeout(r, 1000));
        if (!runningCampaigns.get(campaignId)) break;
      }
      if (!runningCampaigns.get(campaignId)) break;

      const contact = pendingContacts[i];
      try {
        const delayMs =
          i === 0
            ? 0
            : campaign.delayType === "automatic"
            ? Math.random() * (45000 - 15000) + 15000
            : Math.random() *
                ((campaign.delayMax ?? 10) * 60000 - (campaign.delayMin ?? 5) * 60000) +
              (campaign.delayMin ?? 5) * 60000;

        if (delayMs > 0) await new Promise((r) => setTimeout(r, delayMs));
        if (!runningCampaigns.get(campaignId)) break;

        await whatsAppService.sendMessage(campaign.serverId, contact, campaign.messageTemplate, 0);
        await storage.updateContactStatus(contact.id, "sent", { sentAt: new Date() });
      } catch (err: any) {
        console.error(`[Campaign] Failed ${contact.phone}:`, err.message);
        await storage.updateContactStatus(contact.id, "failed", {
          errorMessage: err.message || "Gagal mengirim",
        });
      }
    }

    if (runningCampaigns.get(campaignId)) {
      await storage.updateCampaignStatus(campaignId, "completed");
    }
  } catch (err: any) {
    console.error(`[Campaign ${campaignId}] Error:`, err.message);
    try { await storage.updateCampaignStatus(campaignId, "failed"); } catch {}
  } finally {
    runningCampaigns.delete(campaignId);
  }
}
