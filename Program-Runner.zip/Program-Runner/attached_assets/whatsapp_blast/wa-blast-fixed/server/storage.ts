import { db } from "./db";
import { 
  servers, campaigns, campaignContacts,
  type Server, type Campaign, type CampaignContact,
  type InsertServer, type InsertCampaign, type InsertCampaignContact 
} from "@shared/schema";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getServers(): Promise<Server[]>;
  getServer(id: number): Promise<Server | undefined>;
  createServer(server: InsertServer): Promise<Server>;
  updateServerStatus(id: number, status: string, qrCode?: string): Promise<Server>;
  deleteServer(id: number): Promise<void>;

  getCampaigns(): Promise<Campaign[]>;
  getCampaign(id: number): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  updateCampaignStatus(id: number, status: string): Promise<Campaign>;
  scheduleCampaign(id: number, scheduleTime: Date): Promise<Campaign>;
  deleteCampaign(id: number): Promise<void>;

  getCampaignContacts(campaignId: number): Promise<CampaignContact[]>;
  createCampaignContacts(contacts: InsertCampaignContact[]): Promise<void>;
  updateContactStatus(id: number, status: string, options?: { errorMessage?: string, sentAt?: Date, readAt?: Date }): Promise<CampaignContact>;

  getDeliveryRate(): Promise<number>;
}

export class DatabaseStorage implements IStorage {
  async getServers(): Promise<Server[]> {
    return await db.select().from(servers);
  }

  async getServer(id: number): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.id, id));
    return server;
  }

  async createServer(server: InsertServer): Promise<Server> {
    const [newServer] = await db.insert(servers).values(server).returning();
    return newServer;
  }

  async updateServerStatus(id: number, status: string, qrCode?: string): Promise<Server> {
    const [updated] = await db.update(servers)
      .set({ status, qrCode })
      .where(eq(servers.id, id))
      .returning();
    return updated;
  }

  async deleteServer(id: number): Promise<void> {
    await db.delete(servers).where(eq(servers.id, id));
  }

  async getCampaigns(): Promise<Campaign[]> {
    return await db.select().from(campaigns);
  }

  async getCampaign(id: number): Promise<Campaign | undefined> {
    const [campaign] = await db.select().from(campaigns).where(eq(campaigns.id, id));
    return campaign;
  }

  async createCampaign(campaign: InsertCampaign): Promise<Campaign> {
    const [newCampaign] = await db.insert(campaigns).values(campaign).returning();
    return newCampaign;
  }

  async updateCampaignStatus(id: number, status: string): Promise<Campaign> {
    const [updated] = await db.update(campaigns)
      .set({ status })
      .where(eq(campaigns.id, id))
      .returning();
    return updated;
  }

  async scheduleCampaign(id: number, scheduleTime: Date): Promise<Campaign> {
    const [updated] = await db.update(campaigns)
      .set({ status: "scheduled", scheduleTime })
      .where(eq(campaigns.id, id))
      .returning();
    return updated;
  }

  async deleteCampaign(id: number): Promise<void> {
    // Delete contacts first (FK constraint)
    await db.delete(campaignContacts).where(eq(campaignContacts.campaignId, id));
    await db.delete(campaigns).where(eq(campaigns.id, id));
  }

  async getCampaignContacts(campaignId: number): Promise<CampaignContact[]> {
    return await db.select().from(campaignContacts).where(eq(campaignContacts.campaignId, campaignId));
  }

  async createCampaignContacts(contacts: InsertCampaignContact[]): Promise<void> {
    if (contacts.length === 0) return;
    await db.insert(campaignContacts).values(contacts);
  }

  async updateContactStatus(id: number, status: string, options?: { errorMessage?: string, sentAt?: Date, readAt?: Date }): Promise<CampaignContact> {
    const updateData: any = { status };
    if (options?.errorMessage !== undefined) updateData.errorMessage = options.errorMessage;
    if (options?.sentAt !== undefined) updateData.sentAt = options.sentAt;
    if (options?.readAt !== undefined) updateData.readAt = options.readAt;

    const [updated] = await db.update(campaignContacts)
      .set(updateData)
      .where(eq(campaignContacts.id, id))
      .returning();
    return updated;
  }

  async getDeliveryRate(): Promise<number> {
    const allContacts = await db.select().from(campaignContacts);
    const total = allContacts.length;
    if (total === 0) return 0;
    const sent = allContacts.filter(c => c.status === "sent" || c.status === "delivered" || c.status === "read").length;
    return Math.round((sent / total) * 1000) / 10; // one decimal
  }
}

export const storage = new DatabaseStorage();
