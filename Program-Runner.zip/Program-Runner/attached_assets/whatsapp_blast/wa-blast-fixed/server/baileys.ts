/**
 * WhatsApp Baileys Integration Module
 * Real implementation using @whiskeysockets/baileys
 */

import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import pino from "pino";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import qrcode from "qrcode";
import type { CampaignContact, Campaign } from "@shared/schema";

// Handle both ESM and CommonJS contexts
let __dirname = path.dirname(path.resolve("."));
try {
  __dirname = path.dirname(fileURLToPath(import.meta.url));
} catch {
  // Fallback for CommonJS bundle
  __dirname = process.cwd();
}

export const SESSIONS_DIR = path.join(__dirname, "..", "sessions");
const logger = pino({ level: "silent" });

fs.mkdirSync(SESSIONS_DIR, { recursive: true });

export interface ServerSession {
  id: number;
  phone: string;
  name?: string | null;
  sock: any;
  status: string;
  qrString: string | null;
  sent: number;
}

const sessions = new Map<number, ServerSession>();
const messageStatusStore = new Map<string, any>();

// ── Spintax ──────────────────────────────────────────────────────────────────
export function expandSpintax(text: string): string {
  return text.replace(/\{([^{}]+)\}/g, (_, group) => {
    const options = group.split("|");
    return options[Math.floor(Math.random() * options.length)];
  });
}

// ── Variable substitution ────────────────────────────────────────────────────
export function expandVariables(text: string, variables: Record<string, any>): string {
  return text.replace(/\{\{([^}]+)\}\}/g, (match, key) => {
    const trimmed = key.trim();
    const val = variables[trimmed] ?? variables[trimmed.toLowerCase()];
    return val !== undefined && val !== null ? String(val) : match;
  });
}

export function calculateRandomDelay(minMinutes: number, maxMinutes: number): number {
  const minMs = minMinutes * 60 * 1000;
  const maxMs = maxMinutes * 60 * 1000;
  return Math.random() * (maxMs - minMs) + minMs;
}

function toJid(phone: string): string {
  const clean = phone.toString().replace(/\D/g, "");
  return `${clean.startsWith("0") ? "62" + clean.slice(1) : clean}@s.whatsapp.net`;
}

// ── Connect / reconnect a session ─────────────────────────────────────────────
async function connectSession(
  id: number,
  phone: string,
  name?: string | null,
  onUpdate?: (session: ServerSession) => void
): Promise<ServerSession> {
  const existing = sessions.get(id);
  if (existing?.sock) {
    try { existing.sock.end(); } catch {}
  }

  const sessionPath = path.join(SESSIONS_DIR, `${id}_${phone}`);
  fs.mkdirSync(sessionPath, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    printQRInTerminal: false,
    browser: ["WA Blast Manager", "Chrome", "122.0.0"],
    syncFullHistory: false,
    generateHighQualityLinkPreview: false,
    connectTimeoutMs: 30000,
    keepAliveIntervalMs: 15000,
  });

  const session: ServerSession = {
    id,
    phone,
    name: name ?? existing?.name,
    sock,
    status: "connecting",
    qrString: null,
    sent: existing?.sent ?? 0,
  };
  sessions.set(id, session);

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update: any) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      session.qrString = qr;
      session.status = "qr_ready";
      console.log(`[QR] QR siap untuk server id=${id} (${phone})`);
      onUpdate?.(session);
    }

    if (connection === "open") {
      session.status = "connected";
      session.qrString = null;
      console.log(`[WA] Connected: id=${id} (${phone})`);
      onUpdate?.(session);
    }

    if (connection === "close") {
      session.qrString = null;
      const code =
        lastDisconnect?.error instanceof Boom
          ? (lastDisconnect.error as Boom).output.statusCode
          : 0;
      const shouldReconnect = code !== DisconnectReason.loggedOut && code !== 401;
      console.log(`[WA] Disconnected id=${id}, code=${code}, reconnect=${shouldReconnect}`);

      if (shouldReconnect) {
        session.status = "reconnecting";
        onUpdate?.(session);
        setTimeout(() => connectSession(id, phone, name, onUpdate), 5000);
      } else {
        session.status = "disconnected";
        sessions.delete(id);
        try {
          fs.rmSync(path.join(SESSIONS_DIR, `${id}_${phone}`), { recursive: true, force: true });
        } catch {}
        onUpdate?.(session);
      }
    }
  });

  sock.ev.on("message-receipt.update", (updates: any[]) => {
    for (const u of updates) {
      const msgId = u.key.id;
      if (!msgId) continue;
      const ex = messageStatusStore.get(msgId) || {};
      if (u.receipt.receiptTimestamp) ex.readStatus = "delivered";
      if (u.receipt.readTimestamp) {
        ex.readStatus = "read";
        ex.readAt = new Date(u.receipt.readTimestamp * 1000).toISOString();
      }
      messageStatusStore.set(msgId, ex);
    }
  });

  sock.ev.on("messages.upsert", ({ messages, type }: any) => {
    if (type !== "notify") return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue;
      const quoted = msg.message?.extendedTextMessage?.contextInfo?.stanzaId;
      if (quoted && messageStatusStore.has(quoted)) {
        const ex = messageStatusStore.get(quoted);
        ex.readStatus = "replied";
        ex.repliedAt = new Date().toISOString();
        messageStatusStore.set(quoted, ex);
      }
    }
  });

  return session;
}

// ── Public WhatsAppService class ──────────────────────────────────────────────
export class WhatsAppService {
  /**
   * Initialize session and wait for QR. Returns base64 image data URL.
   */
  async initializeSession(
    serverId: number,
    phone: string,
    name?: string | null,
    onStatusChange?: (status: string, qrCode?: string) => void
  ): Promise<string> {
    const session = await connectSession(serverId, phone, name, async (s) => {
      if (s.status === "qr_ready" && s.qrString) {
        const qrImage = await qrcode.toDataURL(s.qrString, { width: 300, margin: 2 });
        onStatusChange?.(s.status, qrImage);
      } else {
        onStatusChange?.(s.status);
      }
    });

    // Wait up to 20 seconds for QR or connected
    let waited = 0;
    while (!session.qrString && session.status !== "connected" && waited < 20000) {
      await new Promise((r) => setTimeout(r, 500));
      waited += 500;
    }

    if (session.status === "connected") {
      onStatusChange?.("connected");
      return "already_connected";
    }

    if (!session.qrString) {
      throw new Error("QR tidak muncul. Coba lagi.");
    }

    return await qrcode.toDataURL(session.qrString, { width: 300, margin: 2 });
  }

  getSessionStatus(serverId: number): string {
    return sessions.get(serverId)?.status ?? "disconnected";
  }

  async disconnectSession(serverId: number): Promise<void> {
    const session = sessions.get(serverId);
    if (!session) return;
    try { session.sock?.end(); } catch {}
    sessions.delete(serverId);
    try {
      fs.rmSync(path.join(SESSIONS_DIR, `${serverId}_${session.phone}`), {
        recursive: true, force: true,
      });
    } catch {}
  }

  async sendMessage(
    serverId: number,
    contact: CampaignContact,
    messageTemplate: string,
    delayMs: number
  ): Promise<string> {
    const session = sessions.get(serverId);
    if (!session || session.status !== "connected") {
      throw new Error(`Server ${serverId} belum terhubung`);
    }
    if (delayMs > 0) await new Promise((r) => setTimeout(r, delayMs));

    let message = expandSpintax(messageTemplate);
    message = expandVariables(message, (contact.variables as Record<string, any>) || {});
    const sent = await session.sock.sendMessage(toJid(contact.phone), { text: message });
    session.sent = (session.sent || 0) + 1;
    return sent.key.id;
  }

  async processCampaign(
    campaign: Campaign,
    contacts: CampaignContact[],
    serverId: number,
    onProgress?: (contactId: number, status: string, msgId?: string) => void
  ): Promise<void> {
    const session = sessions.get(serverId);
    if (!session || session.status !== "connected") {
      throw new Error(`Server ${serverId} belum terhubung`);
    }
    for (let i = 0; i < contacts.length; i++) {
      const contact = contacts[i];
      try {
        const delayMs =
          i === 0 ? 0 : calculateRandomDelay(campaign.delayMin ?? 5, campaign.delayMax ?? 10);
        let message = expandSpintax(campaign.messageTemplate);
        message = expandVariables(message, (contact.variables as Record<string, any>) || {});
        if (delayMs > 0) await new Promise((r) => setTimeout(r, delayMs));
        const sent = await session.sock.sendMessage(toJid(contact.phone), { text: message });
        session.sent = (session.sent || 0) + 1;
        onProgress?.(contact.id, "sent", sent.key.id);
      } catch (err: any) {
        console.error(`[Campaign] Failed ${contact.phone}:`, err.message);
        onProgress?.(contact.id, "failed");
      }
    }
  }

  /** Restore all saved sessions from disk on startup */
  async restoreSessions(
    onStatusChange?: (id: number, status: string, qrCode?: string) => void
  ): Promise<void> {
    try {
      const entries = fs.readdirSync(SESSIONS_DIR, { withFileTypes: true });
      for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        const parts = entry.name.split("_");
        if (parts.length < 2) continue;
        const id = parseInt(parts[0]);
        const phone = parts[1];
        if (isNaN(id)) continue;
        const credsPath = path.join(SESSIONS_DIR, entry.name, "creds.json");
        if (!fs.existsSync(credsPath)) continue;
        console.log(`[WA] Restoring session for server id=${id} (${phone})`);
        try {
          await connectSession(id, phone, null, async (s) => {
            if (s.status === "qr_ready" && s.qrString) {
              const qrImage = await qrcode.toDataURL(s.qrString, { width: 300, margin: 2 });
              onStatusChange?.(id, s.status, qrImage);
            } else {
              onStatusChange?.(id, s.status);
            }
          });
        } catch (e: any) {
          console.error(`[WA] Restore failed id=${id}:`, e.message);
        }
      }
    } catch {}
  }

  calculateRandomDelay(minMinutes: number, maxMinutes: number): number {
    return calculateRandomDelay(minMinutes, maxMinutes);
  }

  expandSpintax(text: string): string { return expandSpintax(text); }
  expandVariables(text: string, variables: Record<string, any>): string {
    return expandVariables(text, variables);
  }
}

export const whatsAppService = new WhatsAppService();
