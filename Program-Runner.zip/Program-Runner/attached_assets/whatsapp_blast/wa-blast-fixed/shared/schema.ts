import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name"),
  phone: text("phone").notNull(),
  status: text("status").notNull().default("disconnected"), // disconnected, qr_ready, connected
  qrCode: text("qr_code"), 
});

export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serverId: integer("server_id").references(() => servers.id),
  messageTemplate: text("message_template").notNull(),
  attachmentUrl: text("attachment_url"),
  delayType: text("delay_type").notNull().default("manual"), // automatic, manual
  delayMin: integer("delay_min").notNull().default(5),
  delayMax: integer("delay_max").notNull().default(10),
  scheduleTime: timestamp("schedule_time"),
  status: text("status").notNull().default("pending"), // pending, scheduled, running, paused, completed, failed
  createdAt: timestamp("created_at").defaultNow(),
});

export const campaignContacts = pgTable("campaign_contacts", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => campaigns.id).notNull(),
  phone: text("phone").notNull(),
  variables: jsonb("variables"),
  status: text("status").notNull().default("pending"), // pending, sent, delivered, read, replied, failed
  errorMessage: text("error_message"),
  sentAt: timestamp("sent_at"),
  readAt: timestamp("read_at"),
});

export const insertServerSchema = createInsertSchema(servers).omit({ id: true });
export const insertCampaignSchema = createInsertSchema(campaigns).omit({ id: true, createdAt: true });
export const insertCampaignContactSchema = createInsertSchema(campaignContacts).omit({ id: true });

export type Server = typeof servers.$inferSelect;
export type Campaign = typeof campaigns.$inferSelect;
export type CampaignContact = typeof campaignContacts.$inferSelect;

export type InsertServer = z.infer<typeof insertServerSchema>;
export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type InsertCampaignContact = z.infer<typeof insertCampaignContactSchema>;
