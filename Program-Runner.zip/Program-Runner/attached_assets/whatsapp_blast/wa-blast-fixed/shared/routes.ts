import { z } from 'zod';
import { insertServerSchema, insertCampaignSchema, insertCampaignContactSchema, servers, campaigns, campaignContacts } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  servers: {
    list: {
      method: 'GET' as const,
      path: '/api/servers' as const,
      responses: {
        200: z.array(z.custom<typeof servers.$inferSelect>()),
      }
    },
    get: {
      method: 'GET' as const,
      path: '/api/servers/:id' as const,
      responses: {
        200: z.custom<typeof servers.$inferSelect>(),
        404: errorSchemas.notFound,
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/servers' as const,
      input: insertServerSchema,
      responses: {
        201: z.custom<typeof servers.$inferSelect>(),
        400: errorSchemas.validation,
      }
    },
    delete: {
      method: 'DELETE' as const,
      path: '/api/servers/:id' as const,
      responses: {
        204: z.void(),
        404: errorSchemas.notFound,
      }
    },
    connect: {
      method: 'POST' as const,
      path: '/api/servers/:id/connect' as const,
      responses: {
        200: z.object({ message: z.string() }),
        404: errorSchemas.notFound,
      }
    }
  },
  campaigns: {
    list: {
      method: 'GET' as const,
      path: '/api/campaigns' as const,
      responses: {
        200: z.array(z.custom<typeof campaigns.$inferSelect>()),
      }
    },
    get: {
      method: 'GET' as const,
      path: '/api/campaigns/:id' as const,
      responses: {
        200: z.custom<typeof campaigns.$inferSelect>(),
        404: errorSchemas.notFound,
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/campaigns' as const,
      input: insertCampaignSchema,
      responses: {
        201: z.custom<typeof campaigns.$inferSelect>(),
        400: errorSchemas.validation,
      }
    },
    start: {
      method: 'POST' as const,
      path: '/api/campaigns/:id/start' as const,
      responses: {
        200: z.object({ message: z.string() }),
        404: errorSchemas.notFound,
      }
    }
  },
  contacts: {
    list: {
      method: 'GET' as const,
      path: '/api/campaigns/:campaignId/contacts' as const,
      responses: {
        200: z.array(z.custom<typeof campaignContacts.$inferSelect>()),
      }
    },
    createBulk: {
      method: 'POST' as const,
      path: '/api/campaigns/:campaignId/contacts/bulk' as const,
      input: z.object({
        contacts: z.array(insertCampaignContactSchema.omit({ campaignId: true }))
      }),
      responses: {
        201: z.object({ count: z.number() }),
        400: errorSchemas.validation,
      }
    }
  },
  upload: {
    create: {
      method: 'POST' as const,
      path: '/api/upload' as const,
      responses: {
        200: z.object({ url: z.string(), filename: z.string() }),
        400: errorSchemas.validation,
      }
    },
    parseFile: {
      method: 'POST' as const,
      path: '/api/upload/parse' as const,
      responses: {
        200: z.object({ data: z.array(z.any()) }),
        400: errorSchemas.validation,
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type ServerResponse = z.infer<typeof api.servers.list.responses[200]>[number];
export type CampaignResponse = z.infer<typeof api.campaigns.list.responses[200]>[number];
export type ContactResponse = z.infer<typeof api.contacts.list.responses[200]>[number];
