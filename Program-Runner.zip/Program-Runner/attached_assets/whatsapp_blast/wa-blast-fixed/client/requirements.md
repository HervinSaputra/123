## Packages
papaparse | For parsing CSV files in the browser locally
@types/papaparse | Types for papaparse
date-fns | For date formatting and manipulation
lucide-react | Icons for the application
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility to merge tailwind classes

## Notes
- Expecting QR code to be a base64 string returned in `server.qrCode`.
- Standard CSV parsing expects headers. Phone number should be in a column named 'phone', 'Phone', 'number', etc.
- Dark mode is enforced as the primary aesthetic.
