import { AppLayout } from "@/components/layout";
import { useCampaigns } from "@/hooks/use-campaigns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Send, Calendar, Clock, ArrowRight, Pause, Square, Play, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { format } from "date-fns";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";

function useCampaignAction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, action }: { id: number; action: string }) => {
      const res = await fetch(`/api/campaigns/${id}/${action}`, {
        method: action === "delete" ? "DELETE" : "POST",
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.message || "Gagal");
      }
      return action;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.campaigns.list.path] });
    },
  });
}

export default function AllCampaigns() {
  const { data: campaigns, isLoading } = useCampaigns();
  const { mutate: doAction, isPending } = useCampaignAction();
  const { toast } = useToast();

  const handleAction = (id: number, action: string, label: string) => {
    if (action === "delete" || action === "stop") {
      if (!confirm(`Yakin ingin ${label} campaign ini?`)) return;
    }
    doAction(
      { id, action },
      {
        onSuccess: () => toast({ title: `Campaign ${label} berhasil` }),
        onError: (err: any) => toast({ title: "Error", description: err.message, variant: "destructive" }),
      }
    );
  };

  return (
    <AppLayout>
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-4xl font-display font-bold tracking-tight">Campaigns</h1>
            <p className="text-muted-foreground mt-2 text-lg">View and manage your message broadcasts.</p>
          </div>
          <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl">
            <Link href="/campaigns/new">
              <Send className="w-4 h-4 mr-2" /> Create New
            </Link>
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1,2,3].map(i => <Card key={i} className="h-24 glass-panel animate-pulse bg-secondary/20" />)}
          </div>
        ) : campaigns?.length === 0 ? (
          <div className="text-center py-24 border-2 border-dashed border-border/50 rounded-2xl bg-secondary/10">
            <Send className="w-16 h-16 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-xl font-display font-semibold">No campaigns found</h3>
            <p className="text-muted-foreground mt-2">Start reaching your audience by creating your first campaign.</p>
            <Button asChild variant="outline" className="mt-6 rounded-xl border-border/50">
              <Link href="/campaigns/new">Create Campaign</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {campaigns?.map(campaign => (
              <Card key={campaign.id} className="glass-panel group hover:border-primary/40 transition-all overflow-hidden relative">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                <CardContent className="p-0">
                  <div className="flex flex-col sm:flex-row items-center justify-between p-6 gap-4">
                    <div className="flex-1 w-full">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold font-display">{campaign.name}</h3>
                        <StatusBadge status={campaign.status} />
                      </div>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <Calendar className="w-4 h-4" />
                          {campaign.createdAt ? format(new Date(campaign.createdAt), "d MMM yyyy") : "—"}
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-4 h-4" />
                          {campaign.delayType === "manual"
                            ? `Jeda ${campaign.delayMin}–${campaign.delayMax} menit`
                            : "Auto (Safe Mode)"}
                        </div>
                        {campaign.scheduleTime && (
                          <div className="flex items-center gap-1.5 text-blue-400">
                            <Calendar className="w-4 h-4" />
                            Jadwal: {format(new Date(campaign.scheduleTime), "d MMM yyyy HH:mm")}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
                      {/* Pause / Resume */}
                      {campaign.status === "running" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-xl border-amber-500/50 text-amber-500 hover:bg-amber-500/10"
                          onClick={() => handleAction(campaign.id, "pause", "dijeda")}
                          disabled={isPending}
                        >
                          <Pause className="w-4 h-4 mr-1" /> Pause
                        </Button>
                      )}
                      {campaign.status === "paused" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-xl border-emerald-500/50 text-emerald-500 hover:bg-emerald-500/10"
                          onClick={() => handleAction(campaign.id, "resume", "dilanjutkan")}
                          disabled={isPending}
                        >
                          <Play className="w-4 h-4 mr-1" /> Lanjutkan
                        </Button>
                      )}
                      {(campaign.status === "running" || campaign.status === "paused") && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-xl border-destructive/50 text-destructive hover:bg-destructive/10"
                          onClick={() => handleAction(campaign.id, "stop", "dihentikan")}
                          disabled={isPending}
                        >
                          <Square className="w-4 h-4 mr-1" /> Stop
                        </Button>
                      )}

                      <Button
                        asChild
                        variant="secondary"
                        size="sm"
                        className="rounded-xl group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                      >
                        <Link href={`/campaigns/${campaign.id}`}>
                          Detail <ArrowRight className="w-4 h-4 ml-1" />
                        </Link>
                      </Button>

                      {/* Delete */}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        onClick={() => handleAction(campaign.id, "delete", "dihapus")}
                        disabled={isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    pending: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    scheduled: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    running: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    paused: "bg-amber-400/10 text-amber-400 border-amber-400/20",
    completed: "bg-primary/10 text-primary border-primary/20",
    failed: "bg-destructive/10 text-destructive border-destructive/20",
  };

  const labels: Record<string, string> = {
    pending: "⏳ Pending",
    scheduled: "📅 Terjadwal",
    running: "▶ Berjalan",
    paused: "⏸ Dijeda",
    completed: "✓ Selesai",
    failed: "✕ Dihentikan",
  };

  return (
    <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${styles[status] || styles.pending}`}>
      {labels[status] || status}
    </span>
  );
}
