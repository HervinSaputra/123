import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { AppLayout } from "@/components/layout";
import { useServers } from "@/hooks/use-servers";
import { useCreateCampaign, useCreateBulkContacts, useStartCampaign } from "@/hooks/use-campaigns";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Server, Users, MessageSquare, Clock, Paperclip, UploadCloud,
  Braces, SendHorizonal, Calendar as CalendarIcon, CheckCircle2,
  X, Image, FileText, Eye
} from "lucide-react";
import Papa from "papaparse";
import * as XLSX from "xlsx";

export default function NewCampaign() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { data: servers } = useServers();
  const createCampaign = useCreateCampaign();
  const createContacts = useCreateBulkContacts();
  const startCampaign = useStartCampaign();

  const [name, setName] = useState("");
  const [serverId, setServerId] = useState("");
  const [messageTemplate, setMessageTemplate] = useState("");
  const [delayType, setDelayType] = useState("manual");
  const [delayMin, setDelayMin] = useState("5");
  const [delayMax, setDelayMax] = useState("10");

  const [contacts, setContacts] = useState<any[]>([]);
  const [variables, setVariables] = useState<string[]>([]);
  const [manualInput, setManualInput] = useState("");
  const [isParsing, setIsParsing] = useState(false);

  // Attachment state
  const [attachment, setAttachment] = useState<{ url: string; filename: string; mimetype: string } | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const attachmentInputRef = useRef<HTMLInputElement>(null);

  // Schedule state
  const [showScheduleDialog, setShowScheduleDialog] = useState(false);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");
  const [pendingCampaignId, setPendingCampaignId] = useState<number | null>(null);
  const [isScheduling, setIsScheduling] = useState(false);

  // Preview state
  const [showPreview, setShowPreview] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const connectedServers = servers?.filter((s) => s.status === "connected") || [];

  // ── Parse XLSX ──────────────────────────────────────────────────────────────
  const parseXLSX = (file: File): Promise<{ headers: string[]; data: any[] }> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: "array" });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
          if (jsonData.length < 2) {
            reject(new Error("File kosong atau tidak ada data"));
            return;
          }
          const headers = jsonData[0].map((h: any) => String(h).trim());
          const rows = jsonData.slice(1).map((row) => {
            const obj: any = {};
            headers.forEach((h, i) => {
              obj[h] = row[i] !== undefined ? String(row[i]) : "";
            });
            return obj;
          }).filter((row) => Object.values(row).some((v) => v !== ""));
          resolve({ headers, data: rows });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error("Gagal membaca file"));
      reader.readAsArrayBuffer(file);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsParsing(true);

    try {
      const isXLSX = file.name.endsWith(".xlsx") || file.name.endsWith(".xls");

      if (isXLSX) {
        const { headers, data } = await parseXLSX(file);
        setVariables(headers);
        const phoneCol = headers.find(
          (h) => h.toLowerCase().includes("phone") || h.toLowerCase().includes("number") ||
                 h.toLowerCase().includes("no") || h.toLowerCase().includes("hp") ||
                 h.toLowerCase().includes("telepon") || h.toLowerCase().includes("wa")
        );
        const parsedContacts = data
          .map((row) => ({
            phone: phoneCol
              ? String(row[phoneCol] || "").replace(/\D/g, "")
              : String(Object.values(row)[0] || "").replace(/\D/g, ""),
            variables: row,
          }))
          .filter((c) => c.phone.length > 5);
        setContacts(parsedContacts);
        toast({
          title: "File XLSX berhasil diparse",
          description: `Ditemukan ${parsedContacts.length} kontak valid. Variabel: ${headers.join(", ")}`,
        });
      } else {
        // CSV
        Papa.parse(file, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
            if (results.data.length > 0) {
              const headers = Object.keys(results.data[0] as object);
              setVariables(headers);
              const phoneCol = headers.find(
                (h) => h.toLowerCase().includes("phone") || h.toLowerCase().includes("number") ||
                       h.toLowerCase().includes("no") || h.toLowerCase().includes("hp") ||
                       h.toLowerCase().includes("telepon") || h.toLowerCase().includes("wa")
              );
              const parsedContacts = (results.data as any[])
                .map((row) => ({
                  phone: phoneCol
                    ? String(row[phoneCol]).replace(/\D/g, "")
                    : String(Object.values(row)[0]).replace(/\D/g, ""),
                  variables: row,
                }))
                .filter((c) => c.phone.length > 5);
              setContacts(parsedContacts);
              toast({
                title: "File CSV berhasil diparse",
                description: `Ditemukan ${parsedContacts.length} kontak. Variabel: ${headers.join(", ")}`,
              });
            }
            setIsParsing(false);
          },
          error: () => {
            toast({ title: "Error parsing CSV", variant: "destructive" });
            setIsParsing(false);
          },
        });
        return;
      }
    } catch (err: any) {
      toast({ title: "Error membaca file", description: err.message, variant: "destructive" });
    }
    setIsParsing(false);
    // Reset input
    e.target.value = "";
  };

  const handleManualInputParse = () => {
    if (!manualInput.trim()) return;
    const lines = manualInput.split(/[\n,;]+/);
    const parsedContacts = lines
      .map((l) => l.trim())
      .filter((l) => l.length > 5)
      .map((phone) => ({ phone: phone.replace(/\D/g, ""), variables: { phone } }));
    setContacts(parsedContacts);
    setVariables(["phone"]);
    toast({ title: "Nomor diparse", description: `Ditemukan ${parsedContacts.length} nomor.` });
  };

  const insertVariable = (variable: string) => {
    if (textareaRef.current) {
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const text = messageTemplate;
      const newText = text.substring(0, start) + `{{${variable}}}` + text.substring(end);
      setMessageTemplate(newText);
      setTimeout(() => {
        textareaRef.current?.focus();
        textareaRef.current?.setSelectionRange(
          start + variable.length + 4,
          start + variable.length + 4
        );
      }, 0);
    } else {
      setMessageTemplate((prev) => prev + `{{${variable}}}`);
    }
  };

  const insertSpintax = () => {
    setMessageTemplate((prev) => prev + "{Hello|Hi|Greetings}");
  };

  // Upload attachment to server
  const handleAttachmentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch("/api/upload/media", {
        method: "POST",
        body: formData,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Upload gagal");
      const data = await res.json();
      setAttachment(data);
      toast({ title: "File berhasil diupload", description: data.filename });
    } catch (err: any) {
      toast({ title: "Gagal upload file", description: err.message, variant: "destructive" });
    }
    setIsUploading(false);
    e.target.value = "";
  };

  // Generate preview message (replace variables with first contact's data)
  const getPreviewMessage = () => {
    let msg = messageTemplate;
    // Expand spintax (take first option)
    msg = msg.replace(/\{([^{}]+)\}/g, (_, group) => {
      const options = group.split("|");
      return options[0];
    });
    // Replace variables with first contact's data or placeholder
    if (contacts.length > 0 && contacts[0].variables) {
      const vars = contacts[0].variables;
      msg = msg.replace(/\{\{([^}]+)\}\}/g, (match, key) => {
        const trimmed = key.trim();
        return vars[trimmed] ?? vars[trimmed.toLowerCase()] ?? `[${trimmed}]`;
      });
    } else {
      msg = msg.replace(/\{\{([^}]+)\}\}/g, (_, key) => `[${key.trim()}]`);
    }
    return msg;
  };

  const prepareAndCreate = async (): Promise<number | null> => {
    if (!name || !serverId || !messageTemplate || contacts.length === 0) {
      toast({
        title: "Field tidak lengkap",
        description: "Isi semua field wajib dan tambahkan kontak.",
        variant: "destructive",
      });
      return null;
    }
    const campaign = await createCampaign.mutateAsync({
      name,
      serverId: parseInt(serverId),
      messageTemplate,
      attachmentUrl: attachment?.url || null,
      delayType,
      delayMin: parseInt(delayMin),
      delayMax: parseInt(delayMax),
      status: "pending",
    });
    await createContacts.mutateAsync({ campaignId: campaign.id, contacts });
    return campaign.id;
  };

  const handleStartNow = async () => {
    try {
      const cid = await prepareAndCreate();
      if (!cid) return;
      await startCampaign.mutateAsync(cid);
      toast({ title: "Campaign Dimulai!", description: "Pesan sedang dikirim." });
      setLocation(`/campaigns/${cid}`);
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  };

  const handleOpenSchedule = async () => {
    try {
      const cid = await prepareAndCreate();
      if (!cid) return;
      setPendingCampaignId(cid);
      const dt = new Date(Date.now() + 60 * 60 * 1000);
      setScheduleDate(dt.toISOString().slice(0, 10));
      setScheduleTime(dt.toTimeString().slice(0, 5));
      setShowScheduleDialog(true);
    } catch (error: any) {
      toast({ title: "Error membuat campaign", description: error.message, variant: "destructive" });
    }
  };

  const handleConfirmSchedule = async () => {
    if (!pendingCampaignId || !scheduleDate || !scheduleTime) {
      toast({ title: "Pilih tanggal dan waktu", variant: "destructive" });
      return;
    }
    const scheduleISO = `${scheduleDate}T${scheduleTime}:00`;
    const scheduleDateTime = new Date(scheduleISO);
    if (isNaN(scheduleDateTime.getTime()) || scheduleDateTime <= new Date()) {
      toast({ title: "Waktu harus di masa depan", variant: "destructive" });
      return;
    }

    setIsScheduling(true);
    try {
      const res = await fetch(`/api/campaigns/${pendingCampaignId}/schedule`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ scheduleTime: scheduleDateTime.toISOString() }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Gagal menjadwalkan");
      }
      toast({
        title: "Campaign Dijadwalkan!",
        description: `Akan dikirim pada ${scheduleDateTime.toLocaleString("id-ID")}.`,
      });
      setShowScheduleDialog(false);
      setLocation(`/campaigns/${pendingCampaignId}`);
    } catch (error: any) {
      toast({ title: "Error menjadwalkan", description: error.message, variant: "destructive" });
    } finally {
      setIsScheduling(false);
    }
  };

  const isSubmitting = createCampaign.isPending || createContacts.isPending || startCampaign.isPending;

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8 pb-20 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div>
          <h1 className="text-4xl font-display font-bold tracking-tight">Buat Campaign</h1>
          <p className="text-muted-foreground mt-2 text-lg">
            Konfigurasi pesan, audience, dan aturan pengiriman.
          </p>
        </div>

        <div className="space-y-8">
          {/* STEP 1 */}
          <Card className="glass-panel border-border/50 shadow-xl overflow-hidden">
            <div className="bg-secondary/40 p-4 border-b border-border/50 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">1</div>
              <h2 className="text-xl font-display font-semibold">Pengaturan Umum</h2>
            </div>
            <CardContent className="p-6 space-y-6">
              <div className="space-y-3">
                <Label>Nama Campaign <span className="text-destructive">*</span></Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="mis. Promo Lebaran"
                  className="bg-background border-border/50 text-lg py-6 px-4 rounded-xl"
                />
              </div>
              <div className="space-y-3">
                <Label>Server Pengirim <span className="text-destructive">*</span></Label>
                <Select value={serverId} onValueChange={setServerId}>
                  <SelectTrigger className="bg-background border-border/50 h-14 rounded-xl">
                    <SelectValue placeholder="Pilih nomor WhatsApp yang terhubung" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    {connectedServers.length === 0 ? (
                      <div className="p-4 text-sm text-muted-foreground text-center">
                        Tidak ada server terhubung.
                      </div>
                    ) : (
                      connectedServers.map((s) => (
                        <SelectItem key={s.id} value={s.id.toString()}>
                          {s.name || s.phone} ({s.phone})
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* STEP 2 */}
          <Card className="glass-panel border-border/50 shadow-xl overflow-hidden">
            <div className="bg-secondary/40 p-4 border-b border-border/50 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">2</div>
              <h2 className="text-xl font-display font-semibold">Penerima</h2>
            </div>
            <CardContent className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <Label>Upload CSV / XLSX</Label>
                  <div className="border-2 border-dashed border-border/50 rounded-2xl p-8 text-center hover:bg-secondary/20 transition-colors relative group cursor-pointer">
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls"
                      onChange={handleFileUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    {isParsing ? (
                      <div className="flex flex-col items-center gap-2">
                        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                        <p className="text-sm text-muted-foreground">Memproses file...</p>
                      </div>
                    ) : (
                      <>
                        <UploadCloud className="w-10 h-10 mx-auto text-muted-foreground group-hover:text-primary transition-colors mb-3" />
                        <p className="text-sm font-medium">Klik atau drag file untuk upload</p>
                        <p className="text-xs text-muted-foreground mt-1">CSV atau XLSX — baris pertama = header kolom</p>
                      </>
                    )}
                  </div>
                </div>
                <div className="space-y-4">
                  <Label>Atau Paste Nomor Manual</Label>
                  <Textarea
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    placeholder="Masukkan nomor, pisahkan dengan koma atau baris baru..."
                    className="h-32 bg-background border-border/50 rounded-xl resize-none"
                  />
                  <Button onClick={handleManualInputParse} variant="secondary" className="w-full rounded-xl">
                    Parse Teks
                  </Button>
                </div>
              </div>

              {contacts.length > 0 && (
                <div className="mt-4 space-y-3">
                  <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <Users className="w-5 h-5 text-primary" />
                      <span className="font-medium text-primary">{contacts.length} kontak siap</span>
                    </div>
                  </div>

                  {/* Variables display */}
                  {variables.length > 0 && (
                    <div className="p-4 rounded-xl bg-secondary/30 border border-border/50">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                        Variabel yang tersedia dari file ({variables.length} kolom):
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {variables.map((v) => (
                          <span
                            key={v}
                            className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono font-medium border border-primary/20"
                          >
                            {`{{${v}}}`}
                          </span>
                        ))}
                      </div>
                      <p className="text-xs text-muted-foreground mt-3">
                        Contoh data pertama:{" "}
                        {variables.slice(0, 3).map((v) => (
                          <span key={v} className="font-mono text-foreground">
                            {v}={String(contacts[0]?.variables?.[v] ?? "—")}{"  "}
                          </span>
                        ))}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* STEP 3 — Message */}
          <Card className="glass-panel border-border/50 shadow-xl overflow-hidden">
            <div className="bg-secondary/40 p-4 border-b border-border/50 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">3</div>
              <h2 className="text-xl font-display font-semibold">Desain Pesan</h2>
            </div>
            <CardContent className="p-6 space-y-6">
              <div className="flex flex-wrap gap-2 mb-2">
                <Button type="button" variant="outline" size="sm" onClick={insertSpintax} className="rounded-lg border-border/50 bg-secondary/30">
                  <Braces className="w-4 h-4 mr-2 text-accent" /> Insert Spintax
                </Button>
                {variables.map((v) => (
                  <Button key={v} type="button" variant="outline" size="sm" onClick={() => insertVariable(v)}
                    className="rounded-lg border-border/50 hover:bg-primary/10 hover:border-primary/40 hover:text-primary font-mono text-xs">
                    {`{{${v}}}`}
                  </Button>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Textarea */}
                <div className="space-y-2">
                  <Textarea
                    ref={textareaRef}
                    value={messageTemplate}
                    onChange={(e) => setMessageTemplate(e.target.value)}
                    placeholder="Ketik pesan... Gunakan {Hi|Hello} untuk variasi dan {{nama_kolom}} untuk variabel."
                    className="min-h-[200px] bg-background border-border/50 text-base rounded-xl p-4 leading-relaxed"
                  />
                  <p className="text-xs text-muted-foreground">
                    Spintax: {`{kata|kata}`} · Variabel: {`{{nama_kolom}}`}
                  </p>
                </div>

                {/* WhatsApp Preview */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-muted-foreground">Preview Chat WhatsApp</p>
                    <Button type="button" variant="ghost" size="sm" onClick={() => setShowPreview(true)} className="text-xs rounded-lg">
                      <Eye className="w-3 h-3 mr-1" /> Fullscreen
                    </Button>
                  </div>
                  <WhatsAppBubble message={getPreviewMessage()} attachment={attachment} />
                </div>
              </div>

              {/* Attachment */}
              <div className="pt-4 border-t border-border/50">
                <Label className="mb-3 block">Lampiran (Opsional)</Label>
                <div className="flex items-center gap-4">
                  <input
                    type="file"
                    ref={attachmentInputRef}
                    accept="image/*,video/*,application/pdf,.doc,.docx"
                    onChange={handleAttachmentUpload}
                    className="hidden"
                  />
                  <Button
                    variant="outline"
                    className="rounded-xl border-border/50"
                    type="button"
                    onClick={() => attachmentInputRef.current?.click()}
                    disabled={isUploading}
                  >
                    {isUploading ? (
                      <><div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" /> Uploading...</>
                    ) : (
                      <><Paperclip className="w-4 h-4 mr-2" /> Pilih File</>
                    )}
                  </Button>
                  {attachment && (
                    <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-primary/5 border border-primary/20 flex-1">
                      {attachment.mimetype?.startsWith("image") ? (
                        <Image className="w-4 h-4 text-primary" />
                      ) : (
                        <FileText className="w-4 h-4 text-primary" />
                      )}
                      <span className="text-sm text-primary truncate flex-1">{attachment.filename}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="w-6 h-6 rounded-full hover:bg-destructive/10 hover:text-destructive"
                        onClick={() => setAttachment(null)}
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                  {!attachment && !isUploading && (
                    <span className="text-sm text-muted-foreground italic">Gambar, video, atau PDF</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* STEP 4 */}
          <Card className="glass-panel border-border/50 shadow-xl overflow-hidden">
            <div className="bg-secondary/40 p-4 border-b border-border/50 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold">4</div>
              <h2 className="text-xl font-display font-semibold">Aturan Pengiriman</h2>
            </div>
            <CardContent className="p-6 space-y-8">
              <div className="space-y-4">
                <Label className="text-base">Jeda Antar Pesan</Label>
                <RadioGroup value={delayType} onValueChange={setDelayType} className="flex flex-col sm:flex-row gap-4">
                  <div
                    className={`flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer transition-colors ${delayType === "manual" ? "border-primary bg-primary/5" : "border-border/50"}`}
                    onClick={() => setDelayType("manual")}
                  >
                    <RadioGroupItem value="manual" id="r1" />
                    <Label htmlFor="r1" className="cursor-pointer font-medium">Jeda Custom Acak</Label>
                  </div>
                  <div
                    className={`flex items-center space-x-2 border p-4 rounded-xl flex-1 cursor-pointer transition-colors ${delayType === "automatic" ? "border-primary bg-primary/5" : "border-border/50"}`}
                    onClick={() => setDelayType("automatic")}
                  >
                    <RadioGroupItem value="automatic" id="r2" />
                    <div>
                      <Label htmlFor="r2" className="cursor-pointer font-medium">Otomatis (Safe Mode)</Label>
                      <p className="text-xs text-muted-foreground mt-0.5">Jeda 15-45 detik otomatis</p>
                    </div>
                  </div>
                </RadioGroup>

                {delayType === "manual" && (
                  <div className="flex items-center gap-4 mt-4 animate-in fade-in slide-in-from-top-2">
                    <div className="flex-1 space-y-2">
                      <Label className="text-xs text-muted-foreground">Min Jeda (menit)</Label>
                      <Input type="number" value={delayMin} onChange={(e) => setDelayMin(e.target.value)} className="bg-background rounded-xl" min="1" />
                    </div>
                    <span className="text-muted-foreground mt-6">-</span>
                    <div className="flex-1 space-y-2">
                      <Label className="text-xs text-muted-foreground">Max Jeda (menit)</Label>
                      <Input type="number" value={delayMax} onChange={(e) => setDelayMax(e.target.value)} className="bg-background rounded-xl" min="1" />
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row justify-end gap-4 pt-4 sticky bottom-6 bg-background/80 backdrop-blur-xl p-4 rounded-2xl border border-border shadow-2xl z-20">
            <Button
              variant="outline"
              size="lg"
              className="rounded-xl border-border/50"
              onClick={handleOpenSchedule}
              disabled={isSubmitting}
            >
              <CalendarIcon className="w-5 h-5 mr-2" /> Simpan & Jadwalkan
            </Button>
            <Button
              size="lg"
              className="rounded-xl bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/25 font-bold text-white"
              onClick={handleStartNow}
              disabled={isSubmitting}
            >
              <SendHorizonal className="w-5 h-5 mr-2" />
              {isSubmitting ? "Memproses..." : "Kirim Campaign Sekarang"}
            </Button>
          </div>
        </div>
      </div>

      {/* Schedule Dialog */}
      <Dialog open={showScheduleDialog} onOpenChange={(o) => !isScheduling && setShowScheduleDialog(o)}>
        <DialogContent className="glass-panel border-border/50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl flex items-center gap-2">
              <CalendarIcon className="w-6 h-6 text-primary" /> Jadwalkan Pengiriman
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-6 mt-4">
            <p className="text-muted-foreground text-sm">
              Campaign akan disimpan dan otomatis dikirim pada waktu yang kamu tentukan.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tanggal <span className="text-destructive">*</span></Label>
                <Input
                  type="date"
                  value={scheduleDate}
                  onChange={(e) => setScheduleDate(e.target.value)}
                  min={new Date().toISOString().slice(0, 10)}
                  className="bg-background border-border/50 rounded-xl"
                />
              </div>
              <div className="space-y-2">
                <Label>Waktu <span className="text-destructive">*</span></Label>
                <Input
                  type="time"
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="bg-background border-border/50 rounded-xl"
                />
              </div>
            </div>

            {scheduleDate && scheduleTime && (
              <div className="p-3 rounded-xl bg-primary/5 border border-primary/20 flex items-center gap-2 text-sm">
                <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0" />
                <span>
                  Akan dikirim:{" "}
                  <strong>
                    {new Date(`${scheduleDate}T${scheduleTime}:00`).toLocaleString("id-ID", {
                      weekday: "long", day: "numeric", month: "long", year: "numeric",
                      hour: "2-digit", minute: "2-digit",
                    })}
                  </strong>
                </span>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <Button variant="outline" className="flex-1 rounded-xl" onClick={() => setShowScheduleDialog(false)} disabled={isScheduling}>
                Batal
              </Button>
              <Button
                className="flex-1 rounded-xl bg-gradient-to-r from-primary to-accent hover:opacity-90 font-bold"
                onClick={handleConfirmSchedule}
                disabled={isScheduling || !scheduleDate || !scheduleTime}
              >
                {isScheduling ? "Menjadwalkan..." : "Konfirmasi Jadwal"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Full Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="glass-panel border-border/50 sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Preview Pesan WhatsApp</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <WhatsAppBubble message={getPreviewMessage()} attachment={attachment} large />
            {contacts.length > 0 && (
              <p className="text-xs text-muted-foreground text-center mt-3">
                Menampilkan data kontak pertama sebagai contoh
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}

// ── WhatsApp Chat Bubble Component ─────────────────────────────────────────────
function WhatsAppBubble({ message, attachment, large }: { message: string; attachment: any; large?: boolean }) {
  const now = new Date();
  const timeStr = `${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")}`;

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23d1fae5' fill-opacity='0.3'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\"), linear-gradient(135deg, #e5ddd5 0%, #d1c4b8 100%)",
        minHeight: large ? "300px" : "180px",
      }}
    >
      <div className="p-4 flex flex-col items-end gap-2">
        {/* Header bar */}
        <div className="w-full flex items-center gap-2 mb-2 bg-[#075e54] rounded-t-xl px-3 py-2 -mx-4 -mt-4 px-4">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <span className="text-white text-xs font-bold">WA</span>
          </div>
          <div>
            <p className="text-white text-sm font-semibold">You</p>
            <p className="text-white/70 text-xs">online</p>
          </div>
        </div>

        {/* Message bubble */}
        <div
          className="max-w-[85%] rounded-2xl rounded-tr-sm shadow-sm overflow-hidden"
          style={{ background: "#dcf8c6" }}
        >
          {/* Attachment preview */}
          {attachment && (
            <div className="w-full bg-gray-200">
              {attachment.mimetype?.startsWith("image") ? (
                <img src={attachment.url} alt="attachment" className="w-full h-32 object-cover" />
              ) : (
                <div className="flex items-center gap-2 p-3">
                  <FileText className="w-8 h-8 text-gray-500" />
                  <span className="text-xs text-gray-600 truncate">{attachment.filename}</span>
                </div>
              )}
            </div>
          )}

          <div className="px-3 py-2">
            {message ? (
              <p className="text-[#111b21] text-sm whitespace-pre-wrap break-words leading-relaxed">
                {message}
              </p>
            ) : (
              <p className="text-gray-400 text-sm italic">Ketik pesan di sebelah kiri...</p>
            )}
            <div className="flex items-center justify-end gap-1 mt-1">
              <span className="text-[10px] text-[#667781]">{timeStr}</span>
              <svg className="w-3.5 h-3.5 text-[#53bdeb]" viewBox="0 0 16 11" fill="currentColor">
                <path d="M11.071.653a.56.56 0 0 0-.812 0L6.19 5.3l-1.406-1.39a.56.56 0 0 0-.812 0 .56.56 0 0 0 0 .812l1.812 1.812a.56.56 0 0 0 .812 0l4.475-4.47a.56.56 0 0 0 0-.811zm2.188 0a.56.56 0 0 0-.812 0L8.378 5.3l-.344-.344-.812.812.75.75a.56.56 0 0 0 .812 0l4.475-4.47a.56.56 0 0 0 0-.394z"/>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function FileText({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  );
}
