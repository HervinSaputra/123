import { AppLayout } from "@/components/layout";
import { useCampaigns } from "@/hooks/use-campaigns";
import { useServers } from "@/hooks/use-servers";
import { Activity, Send, CheckCircle2, Server } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";

export default function Dashboard() {
  const { data: campaigns, isLoading: isLoadingCampaigns, refetch: refetchCampaigns } = useCampaigns();
  const { data: servers, isLoading: isLoadingServers } = useServers();

  const { data: deliveryStats } = useQuery({
    queryKey: ["/api/stats/delivery-rate"],
    queryFn: async () => {
      const res = await fetch("/api/stats/delivery-rate", { credentials: "include" });
      if (!res.ok) return { rate: 0 };
      return res.json();
    },
    refetchInterval: 5000,
  });

  // Auto-refresh setiap 5 detik untuk active campaigns yang sedang berjalan
  useEffect(() => {
    const hasRunning = campaigns?.some(c => c.status === "running" || c.status === "scheduled");
    if (!hasRunning) return;
    const interval = setInterval(() => refetchCampaigns(), 5000);
    return () => clearInterval(interval);
  }, [campaigns, refetchCampaigns]);

  const activeCampaigns = campaigns?.filter(c => c.status === "running").length || 0;
  const totalCampaigns = campaigns?.length || 0;
  const connectedServers = servers?.filter(s => s.status === "connected").length || 0;
  const deliveryRate = deliveryStats?.rate ?? 0;
  const deliveryDisplay = deliveryRate > 0 ? `${deliveryRate}%` : "—";

  return (
    <AppLayout>
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div>
          <h1 className="text-4xl font-display font-bold tracking-tight">Overview</h1>
          <p className="text-muted-foreground mt-2 text-lg">Monitor your messaging infrastructure and campaign performance.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard
            title="Total Campaigns"
            value={isLoadingCampaigns ? null : totalCampaigns}
            icon={Send}
            description="All time campaigns"
          />
          <StatCard
            title="Active Campaigns"
            value={isLoadingCampaigns ? null : activeCampaigns}
            icon={Activity}
            description="Currently running"
            highlight={activeCampaigns > 0}
          />
          <StatCard
            title="Connected Servers"
            value={isLoadingServers ? null : connectedServers}
            icon={Server}
            description={`Out of ${servers?.length || 0} total servers`}
          />
          <StatCard
            title="Delivery Rate"
            value={isLoadingCampaigns ? null : deliveryDisplay}
            icon={CheckCircle2}
            description="Berdasarkan data aktual"
            highlight={deliveryRate >= 90}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="glass-panel col-span-2">
            <CardHeader>
              <CardTitle className="font-display">Recent Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingCampaigns ? (
                <div className="space-y-4">
                  {[1,2,3].map(i => <Skeleton key={i} className="h-16 w-full rounded-xl bg-secondary/50" />)}
                </div>
              ) : campaigns?.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Send className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>No campaigns yet. Create one to get started.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {campaigns?.slice(0, 5).map(campaign => (
                    <div key={campaign.id} className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 border border-border/50 hover:bg-secondary/50 transition-colors">
                      <div>
                        <h4 className="font-medium">{campaign.name}</h4>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className={`inline-block w-1.5 h-1.5 rounded-full ${
                            campaign.status === "running" ? "bg-emerald-500 animate-pulse" :
                            campaign.status === "completed" ? "bg-emerald-500" :
                            campaign.status === "failed" ? "bg-destructive" :
                            campaign.status === "paused" ? "bg-amber-500" :
                            "bg-muted-foreground"
                          }`} />
                          <p className="text-sm text-muted-foreground capitalize">{campaign.status}</p>
                        </div>
                      </div>
                      <div className="text-sm font-medium">
                        {new Date(campaign.createdAt!).toLocaleDateString("id-ID")}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="font-display">Server Status</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingServers ? (
                <div className="space-y-4">
                  {[1,2].map(i => <Skeleton key={i} className="h-12 w-full rounded-xl bg-secondary/50" />)}
                </div>
              ) : (
                <div className="space-y-3">
                  {servers?.map(server => (
                    <div key={server.id} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                      <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
                        server.status === "connected" ? "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]" :
                        server.status === "qr_ready" ? "bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.5)] animate-pulse" :
                        "bg-destructive shadow-[0_0_10px_rgba(239,68,68,0.5)]"
                      }`} />
                      <div className="flex-1 overflow-hidden">
                        <p className="text-sm font-medium truncate">{server.name || server.phone}</p>
                      </div>
                      <span className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
                        {server.status.replace("_", " ")}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}

function StatCard({ title, value, icon: Icon, description, trend, trendUp, highlight }: any) {
  return (
    <Card className={`glass-panel hover:shadow-xl transition-all duration-300 ${highlight ? "border-primary/30 shadow-primary/10" : ""}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${highlight ? "bg-primary/20 border-primary/30" : "bg-secondary border-border/50"}`}>
            <Icon className={`w-6 h-6 ${highlight ? "text-primary" : "text-primary"}`} />
          </div>
          {trend && (
            <span className={`text-xs font-medium px-2 py-1 rounded-full ${trendUp ? "bg-emerald-500/10 text-emerald-500" : "bg-destructive/10 text-destructive"}`}>
              {trend}
            </span>
          )}
        </div>
        <div className="mt-4">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="text-3xl font-display font-bold mt-1">
            {value === null ? <Skeleton className="h-9 w-20 mt-1 bg-secondary/50" /> : value}
          </h3>
          <p className="text-xs text-muted-foreground mt-2">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}
