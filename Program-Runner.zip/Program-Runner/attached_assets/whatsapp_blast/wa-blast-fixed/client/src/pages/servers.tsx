import { useState } from "react";
import { AppLayout } from "@/components/layout";
import { useServers, useCreateServer, useDeleteServer, useConnectServer, useServer } from "@/hooks/use-servers";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription } from "@/components/ui/dialog";
import { Plus, Server as ServerIcon, Smartphone, Trash2, QrCode, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Servers() {
  const { data: servers, isLoading } = useServers();
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [activeServerId, setActiveServerId] = useState<number | null>(null);

  return (
    <AppLayout>
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-4xl font-display font-bold tracking-tight">WhatsApp Servers</h1>
            <p className="text-muted-foreground mt-2 text-lg">Manage connected numbers for sending campaigns.</p>
          </div>
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-lg shadow-primary/20 transition-all font-semibold rounded-xl">
                <Plus className="w-4 h-4 mr-2" /> Add Server
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-panel border-border/50 sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="font-display text-2xl">Add New Server</DialogTitle>
                <DialogDescription>Enter the details for the new WhatsApp connection.</DialogDescription>
              </DialogHeader>
              <AddServerForm onSuccess={() => setIsAddOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <Card key={i} className="glass-panel h-48 animate-pulse bg-secondary/20" />
            ))}
          </div>
        ) : servers?.length === 0 ? (
          <div className="text-center py-24 border-2 border-dashed border-border/50 rounded-2xl bg-secondary/10">
            <ServerIcon className="w-16 h-16 mx-auto mb-4 text-muted-foreground/50" />
            <h3 className="text-xl font-display font-semibold">No servers added</h3>
            <p className="text-muted-foreground mt-2 max-w-sm mx-auto">Add a server and scan the QR code to start sending messages.</p>
            <Button onClick={() => setIsAddOpen(true)} variant="outline" className="mt-6 rounded-xl border-border/50">
              Add your first server
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {servers?.map((server) => (
              <ServerCard key={server.id} server={server} onConnectClick={() => setActiveServerId(server.id)} />
            ))}
          </div>
        )}

        <ConnectDialog 
          serverId={activeServerId} 
          onClose={() => setActiveServerId(null)} 
        />
      </div>
    </AppLayout>
  );
}

function AddServerForm({ onSuccess }: { onSuccess: () => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const { mutate, isPending } = useCreateServer();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ name, phone, status: "disconnected" }, {
      onSuccess: () => {
        toast({ title: "Server created successfully" });
        onSuccess();
      },
      onError: (err) => {
        toast({ title: "Error creating server", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">Server Name (Optional)</label>
        <Input 
          value={name} 
          onChange={(e) => setName(e.target.value)} 
          placeholder="e.g. Marketing Line 1"
          className="bg-secondary/50 border-border/50 rounded-xl focus-visible:ring-primary"
        />
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium">Phone Number <span className="text-destructive">*</span></label>
        <Input 
          value={phone} 
          onChange={(e) => setPhone(e.target.value)} 
          placeholder="+1234567890" 
          required
          className="bg-secondary/50 border-border/50 rounded-xl focus-visible:ring-primary"
        />
      </div>
      <Button 
        type="submit" 
        disabled={isPending} 
        className="w-full mt-6 bg-gradient-to-r from-primary to-accent hover:opacity-90 rounded-xl"
      >
        {isPending ? "Creating..." : "Create Server"}
      </Button>
    </form>
  );
}

function ServerCard({ server, onConnectClick }: { server: any, onConnectClick: () => void }) {
  const { mutate: deleteServer, isPending: isDeleting } = useDeleteServer();
  const { toast } = useToast();

  const handleDelete = () => {
    if(confirm("Are you sure you want to delete this server?")) {
      deleteServer(server.id, {
        onSuccess: () => toast({ title: "Server deleted" })
      });
    }
  };

  return (
    <Card className="glass-panel group hover:border-primary/50 transition-colors overflow-hidden relative">
      {server.status === 'connected' && (
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-bl-full -z-10 blur-2xl" />
      )}
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center border border-border/50">
              <Smartphone className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">{server.name || "Unnamed Server"}</h3>
              <p className="text-muted-foreground text-sm font-mono">{server.phone}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={handleDelete}
            disabled={isDeleting}
            className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-full"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>

        <div className="mt-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className={`w-2.5 h-2.5 rounded-full ${
              server.status === 'connected' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 
              server.status === 'qr_ready' ? 'bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)] animate-pulse' : 
              'bg-destructive shadow-[0_0_8px_rgba(239,68,68,0.5)]'
            }`} />
            <span className="text-sm font-medium capitalize tracking-wide">{server.status.replace('_', ' ')}</span>
          </div>

          {server.status !== 'connected' && (
            <Button 
              size="sm" 
              onClick={onConnectClick}
              className="rounded-full bg-secondary hover:bg-primary hover:text-primary-foreground border border-border/50 transition-all"
            >
              <QrCode className="w-4 h-4 mr-2" /> Connect
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function ConnectDialog({ serverId, onClose }: { serverId: number | null, onClose: () => void }) {
  const { data: server, isLoading } = useServer(serverId || 0);
  const { mutate: connect, isPending: isConnecting } = useConnectServer();
  const { toast } = useToast();

  const handleConnect = () => {
    if (serverId) {
      connect(serverId, {
        onSuccess: () => toast({ title: "Connection initiated", description: "Waiting for QR code..." })
      });
    }
  };

  return (
    <Dialog open={!!serverId} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="glass-panel border-border/50 sm:max-w-sm text-center py-10">
        <DialogHeader className="hidden">
          <DialogTitle>Connect Server</DialogTitle>
        </DialogHeader>
        
        {isLoading ? (
          <div className="flex flex-col items-center justify-center space-y-4">
            <RefreshCw className="w-8 h-8 animate-spin text-primary" />
            <p className="text-muted-foreground">Loading server status...</p>
          </div>
        ) : server?.status === 'connected' ? (
          <div className="flex flex-col items-center justify-center space-y-4 animate-in zoom-in duration-300">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mb-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500" />
            </div>
            <h3 className="text-2xl font-display font-bold">Connected Successfully!</h3>
            <p className="text-muted-foreground">This server is ready to send messages.</p>
            <Button onClick={onClose} className="mt-4 rounded-xl px-8">Done</Button>
          </div>
        ) : server?.status === 'qr_ready' && server.qrCode ? (
          <div className="flex flex-col items-center justify-center space-y-6">
            <div>
              <h3 className="text-xl font-display font-bold">Scan QR Code</h3>
              <p className="text-sm text-muted-foreground mt-1">Open WhatsApp on your phone to link</p>
            </div>
            <div className="p-4 bg-white rounded-2xl shadow-xl">
              <img src={server.qrCode} alt="WhatsApp QR Code" className="w-48 h-48" />
            </div>
            <p className="text-xs text-muted-foreground flex items-center">
              <RefreshCw className="w-3 h-3 animate-spin mr-2" /> Waiting for scan...
            </p>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center space-y-6">
            <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center border border-border/50">
              <Smartphone className="w-8 h-8 text-muted-foreground" />
            </div>
            <div>
              <h3 className="text-xl font-display font-bold">Not Connected</h3>
              <p className="text-sm text-muted-foreground mt-2 max-w-[250px]">Click below to generate a QR code for linking your WhatsApp account.</p>
            </div>
            <Button 
              onClick={handleConnect} 
              disabled={isConnecting}
              className="w-full bg-gradient-to-r from-primary to-accent hover:opacity-90 rounded-xl mt-4"
            >
              {isConnecting ? "Initiating..." : "Generate QR Code"}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
import { CheckCircle2 } from "lucide-react";
