import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertCampaign, type InsertCampaignContact } from "@shared/routes";

export function useCampaigns() {
  return useQuery({
    queryKey: [api.campaigns.list.path],
    queryFn: async () => {
      const res = await fetch(api.campaigns.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch campaigns");
      return api.campaigns.list.responses[200].parse(await res.json());
    },
  });
}

export function useCampaign(id: number) {
  return useQuery({
    queryKey: [api.campaigns.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.campaigns.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch campaign");
      return api.campaigns.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreateCampaign() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertCampaign) => {
      const res = await fetch(api.campaigns.create.path, {
        method: api.campaigns.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(api.campaigns.create.input.parse(data)),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create campaign");
      return api.campaigns.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.campaigns.list.path] });
    },
  });
}

export function useStartCampaign() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.campaigns.start.path, { id });
      const res = await fetch(url, {
        method: api.campaigns.start.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to start campaign");
      return api.campaigns.start.responses[200].parse(await res.json());
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [api.campaigns.get.path, id] });
      queryClient.invalidateQueries({ queryKey: [api.campaigns.list.path] });
    },
  });
}

export function useCampaignContacts(campaignId: number) {
  return useQuery({
    queryKey: [api.contacts.list.path, campaignId],
    queryFn: async () => {
      const url = buildUrl(api.contacts.list.path, { campaignId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch contacts");
      return api.contacts.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateBulkContacts() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ campaignId, contacts }: { campaignId: number, contacts: Omit<InsertCampaignContact, 'campaignId'>[] }) => {
      const url = buildUrl(api.contacts.createBulk.path, { campaignId });
      const payload = api.contacts.createBulk.input.parse({ contacts });
      
      const res = await fetch(url, {
        method: api.contacts.createBulk.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create bulk contacts");
      return api.contacts.createBulk.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.contacts.list.path, variables.campaignId] });
    },
  });
}
