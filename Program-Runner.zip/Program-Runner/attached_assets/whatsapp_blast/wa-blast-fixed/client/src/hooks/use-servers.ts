import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertServer } from "@shared/routes";

export function useServers() {
  return useQuery({
    queryKey: [api.servers.list.path],
    queryFn: async () => {
      const res = await fetch(api.servers.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch servers");
      return api.servers.list.responses[200].parse(await res.json());
    },
    // Also poll servers list to catch any status changes
    refetchInterval: 5000,
  });
}

export function useServer(id: number) {
  return useQuery({
    queryKey: [api.servers.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.servers.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch server");
      return api.servers.get.responses[200].parse(await res.json());
    },
    // Poll every 2 seconds while connecting, initializing QR, or waiting for scan
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      return (status === 'disconnected' || status === 'connecting' || status === 'qr_ready' || status === 'reconnecting') ? 2000 : false;
    }
  });
}

export function useCreateServer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertServer) => {
      const res = await fetch(api.servers.create.path, {
        method: api.servers.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(api.servers.create.input.parse(data)),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create server");
      return api.servers.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.servers.list.path] });
    },
  });
}

export function useDeleteServer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.servers.delete.path, { id });
      const res = await fetch(url, {
        method: api.servers.delete.method,
        credentials: "include",
      });
      if (!res.ok && res.status !== 404) throw new Error("Failed to delete server");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.servers.list.path] });
    },
  });
}

export function useConnectServer() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.servers.connect.path, { id });
      const res = await fetch(url, {
        method: api.servers.connect.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to initiate connection");
      return api.servers.connect.responses[200].parse(await res.json());
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [api.servers.get.path, id] });
      queryClient.invalidateQueries({ queryKey: [api.servers.list.path] });
    },
  });
}
